﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_nombre2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_nombre1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btn_dado = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txt_nombre2
        '
        Me.txt_nombre2.Location = New System.Drawing.Point(79, 168)
        Me.txt_nombre2.Name = "txt_nombre2"
        Me.txt_nombre2.Size = New System.Drawing.Size(144, 20)
        Me.txt_nombre2.TabIndex = 24
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(76, 151)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Nombre del jugador 2:"
        '
        'txt_nombre1
        '
        Me.txt_nombre1.Location = New System.Drawing.Point(79, 109)
        Me.txt_nombre1.Name = "txt_nombre1"
        Me.txt_nombre1.Size = New System.Drawing.Size(144, 20)
        Me.txt_nombre1.TabIndex = 22
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(76, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Nombre del jugador 1:"
        '
        'btn_dado
        '
        Me.btn_dado.BackgroundImage = Global.gato.My.Resources.Resources.dado
        Me.btn_dado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_dado.Location = New System.Drawing.Point(94, 213)
        Me.btn_dado.Name = "btn_dado"
        Me.btn_dado.Size = New System.Drawing.Size(120, 103)
        Me.btn_dado.TabIndex = 20
        Me.btn_dado.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Showcard Gothic", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(69, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(154, 60)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "GATO"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(296, 351)
        Me.Controls.Add(Me.txt_nombre2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_nombre1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btn_dado)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Inicio"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_nombre2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_nombre1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btn_dado As Button
    Friend WithEvents Label1 As Label
End Class
