﻿Public Class Form1
    Public n1 = 0, n2 = 0
    Public jugador1 As String
    Public jugador2 As String

    Private Sub btn_dado_Click(sender As Object, e As EventArgs) Handles btn_dado.Click
        jugador1 = txt_nombre1.Text
        jugador2 = txt_nombre2.Text
        Dim random As New Random()
        Dim numero As Integer = random.Next(1, 6)

        If jugador1 = "" And jugador2 = "" Then
            MsgBox("Me da ansiedad, no puedo entrar", MsgBoxStyle.Critical, "Error")
            Exit Sub
        Else
            If n1 = 0 Then
                n1 = numero
            ElseIf n2 = 0 Then
                n2 = numero
            ElseIf n1 = n2 Then
                n1 = 0
                n2 = 0
            End If

            If numero = 1 Then
                btn_dado.BackgroundImage = My.Resources._1d
            End If
            If numero = 2 Then
                btn_dado.BackgroundImage = My.Resources._2d
            End If
            If numero = 3 Then
                btn_dado.BackgroundImage = My.Resources._3d
            End If
            If numero = 4 Then
                btn_dado.BackgroundImage = My.Resources._4d
            End If
            If numero = 5 Then
                btn_dado.BackgroundImage = My.Resources._5d
            End If
            If numero = 6 Then
                btn_dado.BackgroundImage = My.Resources._6d
            End If

            If (n1 > 0) And (n2 > 0) Then
                If n1 > n2 Then
                    MsgBox("El jugador " + txt_nombre1.Text + " empieza", MsgBoxStyle.Information, "Atencion")
                    Form2.Label1.Text = txt_nombre1.Text
                    Form2.Label2.Text = txt_nombre2.Text
                    Form2.Label3.Text = "1"
                    Form2.Show()
                    Me.Close()
                ElseIf n1 = n2 Then
                    n1 = 0
                    n2 = 0
                Else
                    MsgBox("El jugador " + txt_nombre2.Text + " empieza", MsgBoxStyle.Information, "Atencion")
                    Form2.Label1.Text = txt_nombre1.Text
                    Form2.Label2.Text = txt_nombre2.Text
                    Form2.Label3.Text = "2"
                    Form2.Show()
                    Me.Close()
                End If
            End If
        End If
    End Sub
End Class
