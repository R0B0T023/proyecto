﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lbl_turno = New System.Windows.Forms.Label()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        Me.dgv3 = New System.Windows.Forms.DataGridView()
        Me.dgv1o = New System.Windows.Forms.DataGridView()
        Me.dgv2o = New System.Windows.Forms.DataGridView()
        Me.dgv3o = New System.Windows.Forms.DataGridView()
        Me.dgv4 = New System.Windows.Forms.DataGridView()
        Me.dgv7 = New System.Windows.Forms.DataGridView()
        Me.dgv4o = New System.Windows.Forms.DataGridView()
        Me.dgv7o = New System.Windows.Forms.DataGridView()
        Me.dgv5o = New System.Windows.Forms.DataGridView()
        Me.dgv9o = New System.Windows.Forms.DataGridView()
        Me.dgv8o = New System.Windows.Forms.DataGridView()
        Me.dgv6o = New System.Windows.Forms.DataGridView()
        Me.dgv9 = New System.Windows.Forms.DataGridView()
        Me.dgv8 = New System.Windows.Forms.DataGridView()
        Me.dgv6 = New System.Windows.Forms.DataGridView()
        Me.dgv5 = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv1o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv2o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv3o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv4o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv7o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv5o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv9o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv8o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv6o, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(243, 325)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Label1"
        Me.Label1.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(136, 328)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 31)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Label2"
        Me.Label2.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(82, 343)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Label3"
        Me.Label3.Visible = False
        '
        'Button2
        '
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Location = New System.Drawing.Point(128, 13)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 100)
        Me.Button2.TabIndex = 4
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Location = New System.Drawing.Point(243, 13)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 100)
        Me.Button3.TabIndex = 5
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.Location = New System.Drawing.Point(13, 119)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 100)
        Me.Button4.TabIndex = 6
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button5.Location = New System.Drawing.Point(128, 119)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(109, 100)
        Me.Button5.TabIndex = 7
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.Location = New System.Drawing.Point(243, 119)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(109, 100)
        Me.Button6.TabIndex = 8
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button7.Location = New System.Drawing.Point(13, 225)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(109, 100)
        Me.Button7.TabIndex = 9
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button8.Location = New System.Drawing.Point(128, 225)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(109, 100)
        Me.Button8.TabIndex = 10
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button9.Location = New System.Drawing.Point(243, 225)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(109, 100)
        Me.Button9.TabIndex = 11
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Location = New System.Drawing.Point(13, 13)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(109, 100)
        Me.Button1.TabIndex = 3
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lbl_turno
        '
        Me.lbl_turno.AutoSize = True
        Me.lbl_turno.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_turno.Location = New System.Drawing.Point(386, 81)
        Me.lbl_turno.Name = "lbl_turno"
        Me.lbl_turno.Size = New System.Drawing.Size(101, 31)
        Me.lbl_turno.TabIndex = 12
        Me.lbl_turno.Text = "Label4"
        '
        'dgv1
        '
        Me.dgv1.BackgroundColor = System.Drawing.Color.Red
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(13, 13)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.Size = New System.Drawing.Size(109, 100)
        Me.dgv1.TabIndex = 13
        Me.dgv1.Visible = False
        '
        'dgv2
        '
        Me.dgv2.BackgroundColor = System.Drawing.Color.Red
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2.Location = New System.Drawing.Point(128, 13)
        Me.dgv2.Name = "dgv2"
        Me.dgv2.Size = New System.Drawing.Size(109, 100)
        Me.dgv2.TabIndex = 14
        Me.dgv2.Visible = False
        '
        'dgv3
        '
        Me.dgv3.BackgroundColor = System.Drawing.Color.Red
        Me.dgv3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv3.Location = New System.Drawing.Point(243, 13)
        Me.dgv3.Name = "dgv3"
        Me.dgv3.Size = New System.Drawing.Size(109, 100)
        Me.dgv3.TabIndex = 15
        Me.dgv3.Visible = False
        '
        'dgv1o
        '
        Me.dgv1o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv1o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1o.Location = New System.Drawing.Point(12, 13)
        Me.dgv1o.Name = "dgv1o"
        Me.dgv1o.Size = New System.Drawing.Size(109, 100)
        Me.dgv1o.TabIndex = 16
        Me.dgv1o.Visible = False
        '
        'dgv2o
        '
        Me.dgv2o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv2o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2o.Location = New System.Drawing.Point(128, 12)
        Me.dgv2o.Name = "dgv2o"
        Me.dgv2o.Size = New System.Drawing.Size(109, 100)
        Me.dgv2o.TabIndex = 17
        Me.dgv2o.Visible = False
        '
        'dgv3o
        '
        Me.dgv3o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv3o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv3o.Location = New System.Drawing.Point(243, 13)
        Me.dgv3o.Name = "dgv3o"
        Me.dgv3o.Size = New System.Drawing.Size(109, 100)
        Me.dgv3o.TabIndex = 18
        Me.dgv3o.Visible = False
        '
        'dgv4
        '
        Me.dgv4.BackgroundColor = System.Drawing.Color.Red
        Me.dgv4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv4.Location = New System.Drawing.Point(13, 119)
        Me.dgv4.Name = "dgv4"
        Me.dgv4.Size = New System.Drawing.Size(109, 100)
        Me.dgv4.TabIndex = 19
        Me.dgv4.Visible = False
        '
        'dgv7
        '
        Me.dgv7.BackgroundColor = System.Drawing.Color.Red
        Me.dgv7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv7.Location = New System.Drawing.Point(13, 225)
        Me.dgv7.Name = "dgv7"
        Me.dgv7.Size = New System.Drawing.Size(109, 100)
        Me.dgv7.TabIndex = 20
        Me.dgv7.Visible = False
        '
        'dgv4o
        '
        Me.dgv4o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv4o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv4o.Location = New System.Drawing.Point(13, 119)
        Me.dgv4o.Name = "dgv4o"
        Me.dgv4o.Size = New System.Drawing.Size(109, 100)
        Me.dgv4o.TabIndex = 21
        Me.dgv4o.Visible = False
        '
        'dgv7o
        '
        Me.dgv7o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv7o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv7o.Location = New System.Drawing.Point(13, 225)
        Me.dgv7o.Name = "dgv7o"
        Me.dgv7o.Size = New System.Drawing.Size(109, 100)
        Me.dgv7o.TabIndex = 22
        Me.dgv7o.Visible = False
        '
        'dgv5o
        '
        Me.dgv5o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv5o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv5o.Location = New System.Drawing.Point(128, 119)
        Me.dgv5o.Name = "dgv5o"
        Me.dgv5o.Size = New System.Drawing.Size(109, 100)
        Me.dgv5o.TabIndex = 23
        Me.dgv5o.Visible = False
        '
        'dgv9o
        '
        Me.dgv9o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv9o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv9o.Location = New System.Drawing.Point(243, 225)
        Me.dgv9o.Name = "dgv9o"
        Me.dgv9o.Size = New System.Drawing.Size(109, 100)
        Me.dgv9o.TabIndex = 24
        Me.dgv9o.Visible = False
        '
        'dgv8o
        '
        Me.dgv8o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv8o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv8o.Location = New System.Drawing.Point(128, 225)
        Me.dgv8o.Name = "dgv8o"
        Me.dgv8o.Size = New System.Drawing.Size(109, 100)
        Me.dgv8o.TabIndex = 25
        Me.dgv8o.Visible = False
        '
        'dgv6o
        '
        Me.dgv6o.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgv6o.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv6o.Location = New System.Drawing.Point(243, 119)
        Me.dgv6o.Name = "dgv6o"
        Me.dgv6o.Size = New System.Drawing.Size(109, 100)
        Me.dgv6o.TabIndex = 26
        Me.dgv6o.Visible = False
        '
        'dgv9
        '
        Me.dgv9.BackgroundColor = System.Drawing.Color.Red
        Me.dgv9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv9.Location = New System.Drawing.Point(243, 225)
        Me.dgv9.Name = "dgv9"
        Me.dgv9.Size = New System.Drawing.Size(109, 100)
        Me.dgv9.TabIndex = 27
        Me.dgv9.Visible = False
        '
        'dgv8
        '
        Me.dgv8.BackgroundColor = System.Drawing.Color.Red
        Me.dgv8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv8.Location = New System.Drawing.Point(128, 225)
        Me.dgv8.Name = "dgv8"
        Me.dgv8.Size = New System.Drawing.Size(109, 100)
        Me.dgv8.TabIndex = 28
        Me.dgv8.Visible = False
        '
        'dgv6
        '
        Me.dgv6.BackgroundColor = System.Drawing.Color.Red
        Me.dgv6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv6.Location = New System.Drawing.Point(243, 119)
        Me.dgv6.Name = "dgv6"
        Me.dgv6.Size = New System.Drawing.Size(109, 100)
        Me.dgv6.TabIndex = 29
        Me.dgv6.Visible = False
        '
        'dgv5
        '
        Me.dgv5.BackgroundColor = System.Drawing.Color.Red
        Me.dgv5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv5.Location = New System.Drawing.Point(128, 119)
        Me.dgv5.Name = "dgv5"
        Me.dgv5.Size = New System.Drawing.Size(109, 100)
        Me.dgv5.TabIndex = 30
        Me.dgv5.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(386, 13)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 31)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "VS"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(689, 338)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dgv6o)
        Me.Controls.Add(Me.dgv8o)
        Me.Controls.Add(Me.dgv9o)
        Me.Controls.Add(Me.dgv5o)
        Me.Controls.Add(Me.dgv7o)
        Me.Controls.Add(Me.dgv4o)
        Me.Controls.Add(Me.dgv7)
        Me.Controls.Add(Me.dgv4)
        Me.Controls.Add(Me.dgv3o)
        Me.Controls.Add(Me.dgv2o)
        Me.Controls.Add(Me.dgv1o)
        Me.Controls.Add(Me.dgv3)
        Me.Controls.Add(Me.dgv2)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.lbl_turno)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgv5)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.dgv6)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.dgv8)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.dgv9)
        Me.Controls.Add(Me.Button9)
        Me.Name = "Form2"
        Me.Text = "Form2"
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv1o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv2o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv3o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv4o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv7o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv5o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv9o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv8o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv6o, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents lbl_turno As Label
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents dgv2 As DataGridView
    Friend WithEvents dgv3 As DataGridView
    Friend WithEvents dgv1o As DataGridView
    Friend WithEvents dgv2o As DataGridView
    Friend WithEvents dgv3o As DataGridView
    Friend WithEvents dgv4 As DataGridView
    Friend WithEvents dgv7 As DataGridView
    Friend WithEvents dgv4o As DataGridView
    Friend WithEvents dgv7o As DataGridView
    Friend WithEvents dgv5o As DataGridView
    Friend WithEvents dgv9o As DataGridView
    Friend WithEvents dgv8o As DataGridView
    Friend WithEvents dgv6o As DataGridView
    Friend WithEvents dgv9 As DataGridView
    Friend WithEvents dgv8 As DataGridView
    Friend WithEvents dgv6 As DataGridView
    Friend WithEvents dgv5 As DataGridView
    Friend WithEvents Label4 As Label
End Class
