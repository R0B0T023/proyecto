﻿Public Class Form2
    Public vb1x = 0, vb2x = 0, vb3x = 0, vb4x = 0, vb5x = 0, vb6x = 0, vb7x = 0, vb8x = 0, vb9x = 0
    Public vb1o = 0, vb2o = 0, vb3o = 0, vb4o = 0, vb5o = 0, vb6o = 0, vb7o = 0, vb8o = 0, vb9o = 0

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If vb9x = 0 And vb9o = 0 Then
            If Label3.Text = "1" Then
                Button9.BackgroundImage = My.Resources.equis
                Button9.Enabled = False
                vb9x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button9.BackgroundImage = My.Resources.circulo
                Button9.Enabled = False
                vb9o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If vb8x = 0 And vb8o = 0 Then
            If Label3.Text = "1" Then
                Button8.BackgroundImage = My.Resources.equis
                Button8.Enabled = False
                vb8x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button8.BackgroundImage = My.Resources.circulo
                Button8.Enabled = False
                vb8o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If vb7x = 0 And vb7o = 0 Then
            If Label3.Text = "1" Then
                Button7.BackgroundImage = My.Resources.equis
                Button7.Enabled = False
                vb7x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button7.BackgroundImage = My.Resources.circulo
                Button7.Enabled = False
                vb7o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If vb6x = 0 And vb6o = 0 Then
            If Label3.Text = "1" Then
                Button6.BackgroundImage = My.Resources.equis
                Button6.Enabled = False
                vb6x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button6.BackgroundImage = My.Resources.circulo
                Button6.Enabled = False
                vb6o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If vb5x = 0 And vb5o = 0 Then
            If Label3.Text = "1" Then
                Button5.BackgroundImage = My.Resources.equis
                Button5.Enabled = False
                vb5x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button5.BackgroundImage = My.Resources.circulo
                Button5.Enabled = False
                vb5o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If vb4x = 0 And vb4o = 0 Then
            If Label3.Text = "1" Then
                Button4.BackgroundImage = My.Resources.equis
                Button4.Enabled = False
                vb4x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button4.BackgroundImage = My.Resources.circulo
                Button4.Enabled = False
                vb4o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If vb3x = 0 And vb3o = 0 Then
            If Label3.Text = "1" Then
                Button3.BackgroundImage = My.Resources.equis
                Button3.Enabled = False
                vb3x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button3.BackgroundImage = My.Resources.circulo
                Button3.Enabled = False
                vb3o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If vb2x = 0 And vb2o = 0 Then
            If Label3.Text = "1" Then
                Button2.BackgroundImage = My.Resources.equis
                Button2.Enabled = False
                vb2x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button2.BackgroundImage = My.Resources.circulo
                Button2.Enabled = False
                vb2o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub

    Dim res As Integer = 0
    Dim cont As Integer = 0
    Dim atino As Integer = 0
    Dim turno As Integer = 0
    Dim cuenta1 As Integer = 0
    Dim cuenta2 As Integer = 0
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Label3.Text = "1" Then
            lbl_turno.Text = "Turno de " + Label1.Text
        ElseIf Label3.Text = "2" Then
            lbl_turno.Text = "Turno de " + Label2.Text
        End If
        Label4.Text = Label1.Text + " VS " + Label2.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If vb1x = 0 And vb1o = 0 Then
            If Label3.Text = "1" Then
                Button1.BackgroundImage = My.Resources.equis
                Button1.Enabled = False
                vb1x = 1
                ganadores()
                Exit Sub
            ElseIf Label3.Text = "2" Then
                Button1.BackgroundImage = My.Resources.circulo
                Button1.Enabled = False
                vb1o = 1
                ganadores()
                Exit Sub
            End If
        End If
    End Sub
    Public Sub ganadores()
        If vb1x = 1 And vb2x = 1 And vb3x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv1.Visible = True
                dgv2.Visible = True
                dgv3.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb1o = 1 And vb2o = 1 And vb3o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv1o.Visible = True
                dgv2o.Visible = True
                dgv3o.Visible = True
                MsgBox("Gana circulo")
            End If

        ElseIf vb1x = 1 And vb4x = 1 And vb7x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv1.Visible = True
                dgv4.Visible = True
                dgv7.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb1o = 1 And vb4o = 1 And vb7o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv1o.Visible = True
                dgv4o.Visible = True
                dgv7o.Visible = True
                MsgBox("Gana circulo")
            End If

        ElseIf vb7x = 1 And vb8x = 1 And vb9x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv7.Visible = True
                dgv8.Visible = True
                dgv9.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb7o = 1 And vb8o = 1 And vb9o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv7o.Visible = True
                dgv8o.Visible = True
                dgv9o.Visible = True
                MsgBox("Gana circulo")
            End If

        ElseIf vb3x = 1 And vb6x = 1 And vb9x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv3.Visible = True
                dgv6.Visible = True
                dgv9.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb3o = 1 And vb6o = 1 And vb9o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv3o.Visible = True
                dgv6o.Visible = True
                dgv9o.Visible = True
                MsgBox("Gana circulo")
            End If

        ElseIf vb2x = 1 And vb5x = 1 And vb8x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv2.Visible = True
                dgv5.Visible = True
                dgv8.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb2o = 1 And vb5o = 1 And vb8o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv2o.Visible = True
                dgv5o.Visible = True
                dgv8o.Visible = True
                MsgBox("Gana circulo")
            End If

        ElseIf vb4x = 1 And vb5x = 1 And vb6x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv4.Visible = True
                dgv5.Visible = True
                dgv6.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb4o = 1 And vb5o = 1 And vb6o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv4o.Visible = True
                dgv5o.Visible = True
                dgv6o.Visible = True
                MsgBox("Gana circulo")
            End If

        ElseIf vb1x = 1 And vb5x = 1 And vb9x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv1.Visible = True
                dgv5.Visible = True
                dgv9.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb1o = 1 And vb5o = 1 And vb9o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv1o.Visible = True
                dgv5o.Visible = True
                dgv9o.Visible = True
                MsgBox("Gana circulo")
            End If

        ElseIf vb3x = 1 And vb5x = 1 And vb7x = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 1
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 0
            End If
            If cuenta1 > cuenta2 Then
                dgv3.Visible = True
                dgv5.Visible = True
                dgv7.Visible = True
                MsgBox("Gana equis")
            End If

        ElseIf vb3o = 1 And vb5o = 1 And vb7o = 1 Then
            If Label3.Text = "1" Then
                cuenta1 = cuenta1 + 0
            ElseIf Label3.Text = "2" Then
                cuenta2 = cuenta2 + 1
            End If
            If cuenta2 > cuenta1 Then
                dgv3o.Visible = True
                dgv5o.Visible = True
                dgv7o.Visible = True
                MsgBox("Gana circulo")
            End If


        Else
            turno = 1
        End If
        If turno = 1 Then
            If Label3.Text = "1" Then
                Label3.Text = "2"
                lbl_turno.Text = "Turno de " + Label2.Text
            ElseIf Label3.Text = "2" Then
                Label3.Text = "1"
                lbl_turno.Text = "Turno de " + Label1.Text
            End If
        End If
    End Sub

End Class